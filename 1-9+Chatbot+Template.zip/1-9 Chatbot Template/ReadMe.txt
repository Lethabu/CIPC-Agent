Welcome To AiSensy 1-9 Basic Chatbot Template!

Steps To Follow:

1. Extract the downloaded compressed file to a new folder.

2. Restore '1_9ChatbotTemplate_WA' to a new Dialoglow project. (Do Not Extract)

(Dialogflow Agent Settings- Export/Import - Restore)

3. To Configure Responses, Go through 'WhatsApp Responses.pdf'.